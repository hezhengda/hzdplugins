# hzdplugins

This package is the summary of all my personal plugins for my own research. Because although there are many great packages, sometimes they lack some features that is important to me, so I will write my own plugins. Hope it will help you someday.

# How to install it

The installation is really simple, it is `pip install hzdplugins`.

# Official Documentation

The documentation can be viewed in https://hzdplugins.readthedocs.io/en/latest/.
